from setuptools import setup
setup(name='Petpy',
      version='0.1dev',
      packages=['petpy'],
      licesnse='MIT License',
      long_description=open('README.md').read(),
      )

